package dx.queen.newcalculationandmaps.model;

import java.util.List;

@Deprecated
public class NamesListCollection {
    public static List<String> names;


    public static List<String> fillNamesList() {
        names.add("Adding to start in ArrayList : ");
        names.add("Adding to middle in ArrayList : ");
        names.add("Adding to end in ArrayList : ");
        names.add("Adding to start in ArrayList : ");
        names.add("Adding to end in ArrayList : ");
        names.add("Adding to middle in ArrayList : ");
        names.add("Adding to search in ArrayList : ");
        names.add("Adding to start in LinkedList : ");
        names.add("Adding to middle in LinkedList : ");
        names.add("Adding to end in LinkedList : ");
        names.add("Adding to start in LinkedList : ");
        names.add("Adding to end in LinkedList : ");
        names.add("Adding to middle in LinkedList : ");
        names.add("Adding to search in LinkedList : ");
        names.add("Adding to start in CopyOnWriteArrayList : ");
        names.add("Adding to middle in CopyOnWriteArrayList : ");
        names.add("Adding to end in CopyOnWriteArrayList : ");
        names.add("Adding to start in CopyOnWriteArrayList : ");
        names.add("Adding to end in CopyOnWriteArrayList : ");
        names.add("Adding to middle in CopyOnWriteArrayList : ");
        names.add("Adding to search in CopyOnWriteArrayList : ");
        return names;

    }
}
