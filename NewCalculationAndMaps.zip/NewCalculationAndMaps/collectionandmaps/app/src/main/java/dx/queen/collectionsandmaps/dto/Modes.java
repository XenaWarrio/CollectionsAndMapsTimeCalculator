package dx.queen.collectionsandmaps.dto;

public class Modes {
    public static final String COLLECTIONS = "collections";
    public static final String MAPS = "maps";
}
