package dx.queen.collectionsandmaps.presenter;

import java.util.ArrayList;

import dx.queen.collectionsandmaps.MainInterface;
import dx.queen.collectionsandmaps.model.Model;

public class Presenter implements MainInterface.Presenter {

    private ArrayList<String>listforCollection;
    private MainInterface.View view;
    public Model model;

    public Presenter(MainInterface.View view) {
        this.view = view;
    }


    @Override
    public void buttonWasClicked(int elements, int threads, String mode) {
        switch (mode){
            case "collection":
                model.executingCollection(elements, threads);
                break;
            case "maps":
                model.executingCollection(elements, threads);
                break;
        }
    }
}
