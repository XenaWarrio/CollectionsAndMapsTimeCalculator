package dx.queen.collectionsandmaps.model;

import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import dx.queen.collectionsandmaps.dto.TasksMap;

public class MapsCalculation {
    int elements;
    int threads;
    private TasksMap task;
    private TreeMap<Integer, Integer> treemap;
    private HashMap<Integer, Integer> hashMap;
    private ArrayList<String> mainList;
    private ArrayList<Double> time;
    private ArrayList<String> names;

    public MapsCalculation(int elements, int threads) {
        this.elements = elements;
        this.threads = threads;

    }

    public ArrayList<String> calculateMaps() {
        initViews();
        mainList = executing();
        return mainList;
    }

    private void initViews() {
        time = new ArrayList<>();
        names = new ArrayList<>();
        mainList = new ArrayList<>(6);
        treemap = new TreeMap<>();
        hashMap = new HashMap<>();
        fillNamesList();

    }

    private ArrayList<String> executing() {
        int i = 0;
        for (int y = 0; y <= elements; y++) {
            treemap.put(i, y);
            hashMap.put(i, y);
            i++;
        }

        ExecutorService executor = Executors.newFixedThreadPool(threads);
        for (i = 0; i < 6; i++) {
            if (i < 3) {
                task = new TasksMap(treemap, i);
                double startTime = System.nanoTime();
                executor.execute(task);
                double stopTime = System.nanoTime();
                double elapsedTime = stopTime - startTime;
                String time = Double.toString(elapsedTime);

                mainList.add(names.get(i) + " " + time);
            }
            if (i >= 3) {
                task = new TasksMap(hashMap, i);
                double startTime = System.nanoTime();
                executor.execute(task);

                double stopTime = System.nanoTime();
                double elapsedTime = stopTime - startTime;
                String time = Double.toString(elapsedTime);

                mainList.add(names.get(i) + " " + time);


            }
        }
        executor.shutdown();
        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            Log.d("RRR", e.toString());
        }

        return mainList;
    }

    private ArrayList<String> fillNamesList() {
        names.add("Adding to TreeMap : ");
        names.add("Search by key in TreeMap : ");
        names.add("Removing in TreeMap : ");
        names.add("Adding to HashMap : ");
        names.add("Search by key in HashMap : ");
        names.add("Removing in HashMap : ");
        return names;

    }

}
