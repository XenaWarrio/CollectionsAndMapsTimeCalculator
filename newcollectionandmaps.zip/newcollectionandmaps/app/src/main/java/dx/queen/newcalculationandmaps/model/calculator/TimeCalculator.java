package dx.queen.newcalculationandmaps.model.calculator;

import dx.queen.newcalculationandmaps.dto.task.TaskData;

public interface TimeCalculator {
    void execAndSetupTime(TaskData td);
}
