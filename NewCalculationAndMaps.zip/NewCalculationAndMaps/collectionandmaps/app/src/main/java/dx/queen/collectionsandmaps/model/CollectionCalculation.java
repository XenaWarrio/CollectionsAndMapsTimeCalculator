package dx.queen.collectionsandmaps.model;

import android.util.Log;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import dx.queen.collectionsandmaps.dto.TasksCollection;

public class CollectionCalculation {
    int elements;
    int threads;
    private TasksCollection task;
    private ArrayList<String> mainList;
    private ArrayList<Integer> arrayList;
    private ArrayList<Double> time;
    private ArrayList<String> names;
    private LinkedList<Integer> linkedList;
    private CopyOnWriteArrayList<Integer> copyOnWriteArrayList;

    public CollectionCalculation(int elements, int threads) {
        this.elements = elements;
        this.threads = threads;
    }

    public ArrayList<String> calculateCollection() {
        initViews();
        mainList = executing();
        return mainList;
    }


    private void initViews() {
        arrayList = new ArrayList<>();
        linkedList = new LinkedList<>();
        copyOnWriteArrayList = new CopyOnWriteArrayList<>();
        time = new ArrayList<>();
        names = new ArrayList<>();
        mainList = new ArrayList<>();
        fillNamesList();

    }

    private ArrayList<String> executing() {
        for (int y = 0; y <= elements; y++) {
            arrayList.add(y);
            linkedList.add(y);
            copyOnWriteArrayList.add(y);
        }

        ExecutorService executor = Executors.newFixedThreadPool(threads);
        for (int i = 0; i < 21; i++) {
            if (i < 7) {
                task = new TasksCollection(arrayList, i, elements);
                double startTime = System.nanoTime();
                executor.execute(task);

                double stopTime = System.nanoTime();
                double elapsedTime = stopTime - startTime;
                String time = Double.toString(elapsedTime);

                mainList.add(names.get(i) + " " + time);
            }
            if (7 > i & i < 14) {
                task = new TasksCollection(linkedList, i, elements);
                double startTime = System.nanoTime();
                executor.execute(task);

                double stopTime = System.nanoTime();
                double elapsedTime = stopTime - startTime;
                String time = Double.toString(elapsedTime);

                mainList.add(names.get(i) + " " + time);

            }
            if (i > 14) {
                task = new TasksCollection(copyOnWriteArrayList, i, elements);
                double startTime = System.nanoTime();
                executor.execute(task);

                double stopTime = System.nanoTime();
                double elapsedTime = stopTime - startTime;
                String time = Double.toString(elapsedTime);

                mainList.add(names.get(i) + " " + time);

            }
        }
        executor.shutdown();
        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            Log.d("RRR", e.toString());
        }

        return mainList;
    }

    public ArrayList<String> fillNamesList() {
        names.add("Adding to start in ArrayList : ");
        names.add("Adding to middle in ArrayList : ");
        names.add("Adding to end in ArrayList : ");
        names.add("Adding to start in ArrayList : ");
        names.add("Adding to end in ArrayList : ");
        names.add("Adding to middle in ArrayList : ");
        names.add("Adding to search in ArrayList : ");
        names.add("Adding to start in LinkedList : ");
        names.add("Adding to middle in LinkedList : ");
        names.add("Adding to end in LinkedList : ");
        names.add("Adding to start in LinkedList : ");
        names.add("Adding to end in LinkedList : ");
        names.add("Adding to middle in LinkedList : ");
        names.add("Adding to search in LinkedList : ");
        names.add("Adding to start in CopyOnWriteArrayList : ");
        names.add("Adding to middle in CopyOnWriteArrayList : ");
        names.add("Adding to end in CopyOnWriteArrayList : ");
        names.add("Adding to start in CopyOnWriteArrayList : ");
        names.add("Adding to end in CopyOnWriteArrayList : ");
        names.add("Adding to middle in CopyOnWriteArrayList : ");
        names.add("Adding to search in CopyOnWriteArrayList : ");
        return names;

    }

}
