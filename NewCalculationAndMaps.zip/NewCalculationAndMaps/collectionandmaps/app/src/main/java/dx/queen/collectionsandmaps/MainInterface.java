package dx.queen.collectionsandmaps;

import java.util.ArrayList;

public interface MainInterface {

    interface View {


    }

    interface Presenter{
        void buttonWasClicked(int elements ,int treads, String mode);
    }

    interface RepositoryRowView {

        void setTitle(String title);

        void setStarCount(int starCount);
    }

    interface Model{
        ArrayList<String>executingCollection(int elements, int threads);
        ArrayList<String>executingMaps(int elements, int threads);

    }
}
