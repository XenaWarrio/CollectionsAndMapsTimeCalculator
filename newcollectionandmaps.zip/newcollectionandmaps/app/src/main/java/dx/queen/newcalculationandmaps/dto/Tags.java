package dx.queen.newcalculationandmaps.dto;

public class Tags {
    public static final String ADD_TO_START_ARRAY_LIST = "add_to_start_arr_list";
    public static final String ADD_TO_HASH_MAP = "add_to_hash_map";
}
