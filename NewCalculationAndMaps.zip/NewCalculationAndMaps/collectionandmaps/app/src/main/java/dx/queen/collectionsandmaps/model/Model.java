package dx.queen.collectionsandmaps.model;

import java.util.ArrayList;

import dx.queen.collectionsandmaps.MainInterface;

public class Model implements MainInterface.Model {

    private ArrayList<String> mainListCollection;
    private ArrayList<String> mainListMap;
    private CollectionCalculation collectionCalculation;
    private MapsCalculation mapsCalculation;


    @Override
    public ArrayList<String> executingCollection(int elements, int threads) {
        collectionCalculation = new CollectionCalculation(elements, threads);
        mainListCollection = collectionCalculation.calculateCollection();
        return mainListCollection;
    }

    @Override
    public ArrayList<String> executingMaps(int elements, int threads) {
        mapsCalculation = new MapsCalculation(elements, threads);
        mainListMap = mapsCalculation.calculateMaps();
        return mainListMap;
    }

}
